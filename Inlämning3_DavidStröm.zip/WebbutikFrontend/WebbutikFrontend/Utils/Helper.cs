﻿using WebbShop;

namespace WebbutikFrontend.Utils
{
    public static class Helper
    {
        /// <summary>
        /// The connection to the API.
        /// </summary>
        public static readonly WebbShopAPI API = new();
    }
}
