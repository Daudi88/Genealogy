﻿namespace Genealogy
{
    internal class Program
    {
        private static void Main()
        {
            var family = new FamilyTree();
            family.Start();
        }
    }
}